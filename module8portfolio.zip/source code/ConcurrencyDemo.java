public class ConcurrencyDemo {
    private final Object lock = new Object();
    private boolean countUpComplete = false;

    // Method for counting up from 0 to 20
    public void countUp() {
        for (int i = 0; i <= 20; i++) {
            System.out.println("Counting up: " + i);
            try {
                Thread.sleep(100); // Slow down for readability
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        synchronized (lock) {
            countUpComplete = true;
            lock.notify(); // Notify the waiting thread that counting up is complete
        }
    }

    // Method for counting down from 20 to 0
    public void countDown() {
        synchronized (lock) {
            while (!countUpComplete) {
                try {
                    lock.wait(); // Wait until countUpComplete is true
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
        for (int i = 20; i >= 0; i--) {
            System.out.println("Counting down: " + i);
            try {
                Thread.sleep(100); // Slow down for readability
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
