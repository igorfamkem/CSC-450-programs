public class Main {

    public static void main(String[] args) {
        ConcurrencyDemo concurrencyDemo = new ConcurrencyDemo();

        // Create two threads, one for counting up and one for counting down
        Thread t1 = new Thread(concurrencyDemo::countUp);
        Thread t2 = new Thread(concurrencyDemo::countDown);

        // Start the threads
        t1.start();
        t2.start();

        // Wait for both threads to complete
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
